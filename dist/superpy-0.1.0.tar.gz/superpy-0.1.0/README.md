# SuperPy

Description follows (Or look into the files, its not that complicated)